package core;

public class Individual_activity_type {
	String individual_activity_name;

	public Individual_activity_type(String individual_activity_name) {
		super();
		this.individual_activity_name = individual_activity_name;
	}

	public String getIndividual_activity_name() {
		return individual_activity_name;
	}

	public void setIndividual_activity_name(String individual_activity_name) {
		this.individual_activity_name = individual_activity_name;
	}
	

}
