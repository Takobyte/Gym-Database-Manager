package core;

public class Teaches {
	String emp_id;
	String gid;
	public Teaches(String emp_id, String gid) {
		this.emp_id = emp_id;
		this.gid = gid;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	

}
