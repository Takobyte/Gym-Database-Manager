package core;

public class Class_type {
String class_name;

public Class_type(String class_name) {
	super();
	this.class_name = class_name;
}

public String getClass_name() {
	return class_name;
}

public void setClass_name(String class_name) {
	this.class_name = class_name;
}

}
